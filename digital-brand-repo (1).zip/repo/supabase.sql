-- Digital Brand: tabla de solicitudes (pegar en Supabase > SQL Editor > Run)
create table public.solicitudes (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  nombre text not null check (char_length(nombre) between 1 and 120),
  negocio text check (char_length(negocio) <= 120),
  correo text not null check (char_length(correo) between 5 and 160),
  telefono text not null check (char_length(telefono) between 6 and 30),
  servicio text not null check (char_length(servicio) <= 80),
  mensaje text not null check (char_length(mensaje) between 1 and 2000),
  estado text not null default 'nueva' check (estado in ('nueva','contactada','cerrada'))
);
alter table public.solicitudes enable row level security;

-- Cualquier visitante puede ENVIAR una solicitud, pero no leerla
create policy "visitantes envian" on public.solicitudes
  for insert to anon with check (estado = 'nueva');

-- Solo tu correo puede ver, editar y borrar
create policy "admin lee" on public.solicitudes for select to authenticated
  using ((auth.jwt() ->> 'email') = 'digital.brandoec@gmail.com');
create policy "admin edita" on public.solicitudes for update to authenticated
  using ((auth.jwt() ->> 'email') = 'digital.brandoec@gmail.com')
  with check ((auth.jwt() ->> 'email') = 'digital.brandoec@gmail.com');
create policy "admin borra" on public.solicitudes for delete to authenticated
  using ((auth.jwt() ->> 'email') = 'digital.brandoec@gmail.com');
