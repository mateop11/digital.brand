// Envía un aviso por correo (sin datos del cliente) cuando entra una solicitud nueva
Deno.serve(async (req) => {
  const body = await req.json();
  if (body.type !== "INSERT") return new Response("ok");
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${Deno.env.get("RESEND_API_KEY")}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "Digital Brand <onboarding@resend.dev>",
      to: ["digital.brandoec@gmail.com"],
      subject: "Nueva solicitud en la página de Digital Brand",
      html: "<p>Tienes una solicitud nueva. Entra a tu panel administrativo para verla.</p>",
    }),
  });
  return new Response(r.ok ? "ok" : "error", { status: r.ok ? 200 : 500 });
});
