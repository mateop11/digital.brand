# Digital Brand: backend con Supabase

Qué hace: el formulario guarda cada solicitud en Supabase, tú las ves en `admin.html` con tu login y al correo solo llega un aviso de "solicitud nueva".

## Pasos (unos 20 minutos)

1. **Proyecto:** crea una cuenta en supabase.com con digital.brandoec@gmail.com y un proyecto nuevo.
2. **Tabla y seguridad:** en *SQL Editor* pega todo `supabase.sql` y presiona Run.
3. **Tu usuario:** en *Authentication > Users > Add user* crea tu usuario con digital.brandoec@gmail.com y una contraseña fuerte. En *Authentication > Sign In / Providers* desactiva "Allow new users to sign up".
4. **Claves:** en *Project Settings > API* copia el **Project URL** y la clave **anon public**. Pégalas en las dos variables `SB_URL` y `SB_KEY` que están en el `<script>` de `index.html` y de `admin.html`. La clave anon es pública por diseño, la seguridad la dan las reglas del paso 2. Nunca pegues la clave `service_role`.
5. **Aviso por correo:** crea una cuenta gratis en resend.com con el mismo correo y genera una API key. Luego, con la CLI de Supabase:
   ```
   supabase functions deploy notificar --no-verify-jwt
   supabase secrets set RESEND_API_KEY=tu_clave
   ```
   En *Database > Webhooks > Create* elige la tabla `solicitudes`, el evento **Insert** y el tipo **Supabase Edge Functions** apuntando a `notificar`.
6. **Publicar:** sube `index.html` y `admin.html` a Netlify, Vercel o Firebase Hosting. El panel queda en `tudominio.com/admin.html`.

## Notas
- Con la cuenta gratis de Resend y `onboarding@resend.dev`, solo puedes enviar al correo con el que te registraste, justo lo que necesitas. Si luego quieres un remitente propio, verifica tu dominio en Resend.
- Mientras `SB_URL` esté vacío en `index.html`, el formulario sigue ofreciendo los botones de WhatsApp.
- Si Supabase falla, el visitante ve los botones de WhatsApp como respaldo.
